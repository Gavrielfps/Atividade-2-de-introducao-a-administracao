import './style.css'
import heroImg from './assets/hero.png'
import javascriptLogo from './assets/javascript.svg'
import viteLogo from './assets/vite.svg'
import { setupCounter } from './counter.js'
import HelloWorld from './components/Teste.jsx'
import Apresentacao from './components/Apresentacao.jsx'
import Calculadora from './components/Calculadora.jsx'

document.querySelector('#app').innerHTML = `
<section id="center">
  <div class="hero">
    <section id="spacer"></section>
    <HelloWorld></HelloWorld>
    <Apresentacao></Apresentacao>
    <Calculadora></Calculadora>
  </div>
</section>
`

setupCounter(document.querySelector('#counter'))
