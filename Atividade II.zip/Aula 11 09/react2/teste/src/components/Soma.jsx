function Soma() {
    const num1 = 10;
    const num2 = 10;
    const resultadoSoma = num1 + num2;
    return (
        <div>
            <h1>Resultado da soma: {resultadoSoma}</h1>
        </div>
    );
}
export default Soma;