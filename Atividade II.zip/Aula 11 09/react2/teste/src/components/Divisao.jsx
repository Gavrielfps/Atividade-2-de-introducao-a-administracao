function Divisao() {
    const num1 = 60;
    const num2 = 20;
    const resultadoDivisao = num1 / num2;
    return (
        <div>
            <h1>Resultado da divisão: {resultadoDivisao}</h1>
        </div>
    );
}
export default Divisao;