function Subtracao() {
    const num1 = 60;
    const num2 = 40;
    const resultadoSubtracao = num1 - num2;
    return (
        <div>
            <h1>Resultado da subtração: {resultadoSubtracao}</h1>
        </div>
    );
}
export default Subtracao;