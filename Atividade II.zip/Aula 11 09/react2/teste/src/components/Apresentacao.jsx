function Apresentacao() {

    const nome = "Gabriel";
    const idade = 20;
    const Hobby = "Pensar";
    const NumeroDoCartao = 40028922;

  return (
    <div>
      <h1>Apresentação</h1>
      <p>Nome: {nome}</p>
      <p>Idade: {idade}</p>
      <p>Hobby: {Hobby}</p>
      <p>Número do Cartão: {NumeroDoCartao}</p>
    </div>
  );
}

export default Apresentacao;