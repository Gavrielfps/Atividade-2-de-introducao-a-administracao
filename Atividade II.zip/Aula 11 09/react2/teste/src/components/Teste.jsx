function HelloWorld() {

  const num1 = 10;
  const num2 = 20;
  const resultadoSoma = num1 + num2;
  const nome = "Gabrielfps";

  return (
    <div>
      <h1>Hello, World!</h1>
    </div>
  );

}
export default HelloWorld;