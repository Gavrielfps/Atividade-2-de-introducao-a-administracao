function Multiplicacao() {
    const num1 = 10;
    const num2 = 8;
    const resultadoMultiplicacao = num1 * num2;
    return (
        <div>
            <h1>Resultado da multiplicação: {resultadoMultiplicacao}</h1>
        </div>
    );
}
export default Multiplicacao;