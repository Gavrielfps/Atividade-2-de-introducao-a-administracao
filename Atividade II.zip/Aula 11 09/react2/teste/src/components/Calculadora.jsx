import Soma from './Soma.jsx';
import Subtracao from './Subtracao.jsx';
import Multiplicacao from './Multiplicacao.jsx';
import Divisao from './componentes/Divisao.jsx';

function Calculadora() {
    return (
        <div>
            <h1>Calculadora</h1>
            <Soma/>
            <Subtracao/>
            <Multiplicacao/>
            <Divisao/>
        </div>
    );
}

export default Calculadora;